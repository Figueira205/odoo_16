## Module <hr_payroll_account_community>

#### 20.10.2022
#### Version 16.0.1.0.0
#### ADD
- Initial commit

#### 20.03.2023
#### Version 16.0.1.0.0
#### FIX
- Transalation added
