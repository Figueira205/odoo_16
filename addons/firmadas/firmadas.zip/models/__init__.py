from . import crm_lead
from . import sale_order
from . import crm_lead_producto_tipo
from . import crm_lead_producto_subtipo
from . import crm_lead_producto_estatus1
from . import crm_lead_producto_estatus2
from . import crm_lead_producto_estatus3
from . import crm_lead_producto_estatus4
from . import res_partner
from . import res_partner_interviniente

